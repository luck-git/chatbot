import os
import re
from langchain.llms import OpenAI
from langchain.vectorstores import FAISS
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.chains.question_answering import load_qa_chain
from langchain.chat_models import ChatOpenAI


#from langchain.vectorstores import Chroma
#from .scrape_data import save_data
#from .vectorize import create_db


import openai
os.environ["OPENAI_API_KEY"] ="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"



persist_directory = 'demo_db'
embeddings = OpenAIEmbeddings()
vector_db = FAISS.load_local(persist_directory, embeddings)
#llm = OpenAI(temperature=0, model_name="gpt-3.5-turbo-16k")
#llm = ChatOpenAI(temperature=0, model_name="gpt-3.5-turbo-16k")



#os.environ['SERPAPI_API_KEY'] = "db1d211f1b1e39c3d1afcc952aec6b05c3514779dcd25f0f690912a3dd6c2648"
def chat_with_memory(full_prompt):

   
    

    completion = openai.ChatCompletion.create(
  model="gpt-3.5-turbo-16k",
  messages=[
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": full_prompt}
  ]
)

    return (completion.choices[0].message)

def choice(full_prompt):

   
    

    completion = openai.ChatCompletion.create(
  model="gpt-3.5-turbo-16k",
  messages=[
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": full_prompt}
  ]
)
    #print(completion.choices[0].message["content"])
    return (completion.choices[0].message["content"])   
   
    return jsonify({"Answer":reply})

def format_text_and_urls_as_links(messages):
    url_pattern = r'https?://\S+'
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b'
    
    formatted_messages = []
    
    for message in messages:
        urls = re.findall(url_pattern, message)
    
        for url in urls:
            message = message.replace(url, f'<a href="{url}" target="_blank">{url}</a>')
        emails = re.findall(email_pattern, message)
   
        for email in emails:
            message = message.replace(email, f'<a href="mailto:{email}">{email}</a>')
        
        formatted_messages.append(message)
    
    return formatted_messages
'''def format_text_and_urls_as_links(messages):
    url_pattern = r'https?://\S+'
    
    formatted_messages = []
    
    for message in messages:
        # Find all URLs in the message
        urls = re.findall(url_pattern, message)
        
        # Replace each URL with an HTML anchor tag
        for url in urls:
            message = message.replace(url, f'<a href="{url}" target="_blank">{url}</a>')
        
        formatted_messages.append(message)
    
    return formatted_messages'''


   
       
def get_answer(query:str):
    
        mathcing_docs = vector_db.similarity_search(query)
        final_str=f'''Answer the query from the context given only please make sure provide all details along with matching url and email id in new line only and make sure do not provide duplicate url and email id.
        These are url format examples https://magnawavepemf.com/how-it-works/,https://magnawavepemf.com/support-center/,https://magnawavepemf.com/find-a-practitioner-step-1/,https://magnawavepemf.com/find-a-practitioner-step-1/,https://magnawavepemf.com/return-refund-policies/ etc.
        These are email id format example support@magnawavepemf.com,Support@magnawavepemf.com,education@magnawavepemf.com etc.
        Ask useful question to assist better and If question is not match with given context then response 'A' only.
        Context--{mathcing_docs}
        Query--{query}'''
        
        answer=chat_with_memory(final_str)
        #print("get answer",answer["content"],type(answer["content"]))
        responses = [] 
    
        if answer["content"] == 'A':
            answer = choice(query)
            responses.extend([answer])  
        else:
            responses.append(answer["content"]) 
        formatted_response = format_text_and_urls_as_links(responses)    
        return formatted_response  
   